/*
  Theory Archive — live product & stock sync.
  Loads price / stock from the backend and updates the cards already on the page
  (matched by data-name), so the database is the single source of truth.
  If the backend is offline the page just keeps the values written in the HTML.
*/
window.TA_API = 'http://localhost:4000/api';   // <-- change to your deployed URL
window.TA_STOCK = {};                            // { "Product name": unitsLeft }

(function () {
  const money = (n) => '$' + Number(n).toFixed(0);

  function applyTo(el, p) {
    el.dataset.price = money(p.price);
    el.dataset.original = p.original_price ? money(p.original_price) : '';
    el.dataset.stock = p.stock_label;
    el.dataset.tag = p.tag;
    el.dataset.category = p.category || el.dataset.category;
    el.classList.toggle('sold-out', p.stock <= 0);

    const price = el.querySelector('.p-price, .look-price');
    if (price) price.textContent = money(p.price);

    // badge in the top-left corner of the card
    const media = el.querySelector('.p-media');
    if (media) {
      let tag = media.querySelector('.p-tag');
      if (p.tag) {
        if (!tag) {
          tag = document.createElement('span');
          tag.className = 'p-tag';
          media.prepend(tag);
        }
        tag.textContent = p.tag;
      } else if (tag) {
        tag.remove();
      }
    }
  }

  // Only overwrite the placeholder star-rating copy once real reviews exist —
  // a brand-new product with 0 reviews should keep showing nothing rather
  // than a jarring "0.0 from 0 reviews".
  function applyRating(el, summary) {
    if (!summary || !summary.count) return;
    el.dataset.rating = summary.average;
    el.dataset.reviews = summary.count;
  }

  async function taSyncReviewSummaries(cards) {
    const names = [...new Set(Array.from(cards).map((el) => el.dataset.name).filter(Boolean))];
    if (!names.length) return;
    try {
      const res = await fetch(
        window.TA_API + '/reviews/summary?products=' + encodeURIComponent(names.join(',')),
        { credentials: 'include' }
      );
      if (!res.ok) return;
      const { summaries } = await res.json();
      cards.forEach((el) => applyRating(el, summaries[el.dataset.name]));
    } catch (_e) {
      /* backend offline — keep the placeholder ratings */
    }
  }

  async function taSyncProducts() {
    try {
      const res = await fetch(window.TA_API + '/products', { credentials: 'include' });
      if (!res.ok) return;
      const { products } = await res.json();
      const byName = new Map(products.map((p) => [p.name, p]));

      window.TA_STOCK = {};
      products.forEach((p) => (window.TA_STOCK[p.name] = p.stock));

      const cards = document.querySelectorAll('#product-grid .p-card, .look-cell');
      cards.forEach((el) => {
        const p = byName.get(el.dataset.name);
        if (p) applyTo(el, p);
      });

      await taSyncReviewSummaries(cards);
    } catch (_e) {
      /* backend offline — keep the static values */
    }
  }
  window.taSyncProducts = taSyncProducts;

  // Sends the bag to the server; the server re-checks price + stock and subtracts stock.
  window.taPlaceOrder = async function (items, info) {
    const res = await fetch(window.TA_API + '/orders', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        items: items.map((i) => ({ name: i.name, size: i.size, color: i.color, qty: i.qty })),
        name: info.name, email: info.email, address: info.addr, shipping: info.ship,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) { await taSyncProducts(); throw new Error(data.error || 'Could not place your order.'); }
    await taSyncProducts();
    return data.order_no;
  };

  taSyncProducts();
})();
